# cs3510_helper

For HW2 Q3c

Usage:

python gen.py [k value]

Example:

python gen.py 3
